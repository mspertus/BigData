'use strict';
const http = require('http');
var assert = require('assert');
const express= require('express');
const app = express();
const mustache = require('mustache');
const filesystem = require('fs');
const url = require('url');
const hbase = require('hbase-rpc-client');
const hostname = '127.0.0.1';
const port = 3000;

var client = hbase({
    zookeeperHosts: ["localhost:2181"],
    zookeeperRoot: "/hbase"
});

client.on('error', function(err) {
  console.log(err)
})


app.use(express.static('public'));
app.get('/delays.html',function (req, res) {
    const route=req.query['origin'] + req.query['dest'];
    console.log(route);
    const get = new hbase.Get(route);
    client.get("weather_delays_by_route", get, function(err, row) {
	assert.ok(!err, "get returned an error: #{err}");
	if(!row){
            res.send("<html><body>No such route in data</body></html>");
            return;
        }

	function weather_delay(weather) {
	    var flights = row.cols["delay:" + weather + "_flights"].value;
	    var delays = row.cols["delay:" + weather + "_delays"].value;
	    if(flights == 0)
		return " - ";
	    return (delays/flights).toFixed(1); /* One decimal place */
	}

	var template = filesystem.readFileSync("result.mustache").toString();
	var html = mustache.render(template,  {
	    origin : req.query['origin'],
	    dest : req.query['dest'],
	    clear_dly : weather_delay("clear"),
	    fog_dly : weather_delay("fog"),
	    rain_dly : weather_delay("rain"),
	    snow_dly : weather_delay("snow"),
	    hail_dly : weather_delay("hail"),
	    thunder_dly : weather_delay("thunder"),
	    tornado_dly : weather_delay("tornado")
	});
	res.send(html);
    });
});
	
app.listen(port);
